import type { StudyAssessmentReleaseMode } from './study-assessment-governance.js';
import type { StudyMisconceptionCode } from './study-misconception-taxonomy.js';
import {
  STUDY_ASSESSMENT_CORPUS_SCHEMA_VERSION,
  type StudyAssessmentCorpusMetadata,
  type StudyAssessmentCurriculumRef,
  type StudyAssessmentEvidencePurpose,
  type StudyAssessmentRepresentation,
} from './study-assessment-corpus.js';

export const STUDY_ASSESSMENT_ITEM_BANK_VERSION = "study-assessment-items-2026-09-02.1";

export type StudyAssessmentOption = { id: string; text: string };
export type StudyAssessmentReviewStatus = "approved" | "draft" | "rejected";

export type StudyAssessmentItem = {
  key: string;
  version: string;
  conceptKey: string;
  prompt: string;
  options: StudyAssessmentOption[];
  correctOptionId: string;
  explanation: string;
  difficulty: number;
  objectiveCode: string;
  cognitiveOperation: "recall" | "representation" | "application" | "error_detection";
  misconceptionOptionIds: string[];
  misconceptionByOptionId: Partial<Record<string, StudyMisconceptionCode>>;
  reviewStatus: StudyAssessmentReviewStatus;
  releaseMode: StudyAssessmentReleaseMode;
  corpus: StudyAssessmentCorpusMetadata;
};

const CURRICULUM_BY_CONCEPT: Record<string, { subject: string; refs: StudyAssessmentCurriculumRef[] }> = {
  'math.trigonometry.functions': { subject: 'mathematics', refs: [
    { curriculumKey: 'sg.seab.olevel.additional-mathematics.4049', curriculumVersion: '2026', objectiveCode: 'G1', level: 'O-Level Additional Mathematics' },
    { curriculumKey: 'in.nta.jeemain.paper1', curriculumVersion: '2026', objectiveCode: 'Mathematics Unit 14', level: 'JEE Main Paper 1' },
  ] },
  'math.trigonometry.identities': { subject: 'mathematics', refs: [
    { curriculumKey: 'sg.seab.olevel.additional-mathematics.4049', curriculumVersion: '2026', objectiveCode: 'G1', level: 'O-Level Additional Mathematics' },
    { curriculumKey: 'in.nta.jeemain.paper1', curriculumVersion: '2026', objectiveCode: 'Mathematics Unit 14', level: 'JEE Main Paper 1' },
  ] },
  'math.vector.scalar-vector': { subject: 'mathematics', refs: [
    { curriculumKey: 'sg.seab.olevel.physics.6091', curriculumVersion: '2026', objectiveCode: '1(f)', level: 'O-Level Physics' },
    { curriculumKey: 'in.nta.jeemain.paper1', curriculumVersion: '2026', objectiveCode: 'Mathematics Unit 12', level: 'JEE Main Paper 1' },
  ] },
  'math.vector.resultant': { subject: 'mathematics', refs: [
    { curriculumKey: 'sg.seab.olevel.physics.6091', curriculumVersion: '2026', objectiveCode: '1(g)', level: 'O-Level Physics' },
    { curriculumKey: 'in.nta.jeemain.paper1', curriculumVersion: '2026', objectiveCode: 'Mathematics Unit 12', level: 'JEE Main Paper 1' },
  ] },
  'math.vector.components': { subject: 'mathematics', refs: [
    { curriculumKey: 'in.nta.jeemain.paper1', curriculumVersion: '2026', objectiveCode: 'Mathematics Unit 12', level: 'JEE Main Paper 1' },
  ] },
  'physics.kinematics.speed-velocity-acceleration': { subject: 'physics', refs: [
    { curriculumKey: 'sg.seab.olevel.physics.6091', curriculumVersion: '2026', objectiveCode: '2(a-d)', level: 'O-Level Physics' },
    { curriculumKey: 'in.nta.jeemain.paper1', curriculumVersion: '2026', objectiveCode: 'Physics Unit 2', level: 'JEE Main Paper 1' },
  ] },
  'physics.kinematics.motion-graphs': { subject: 'physics', refs: [
    { curriculumKey: 'sg.seab.olevel.physics.6091', curriculumVersion: '2026', objectiveCode: '2(e-h)', level: 'O-Level Physics' },
  ] },
  'physics.kinematics.motion-in-plane': { subject: 'physics', refs: [
    { curriculumKey: 'in.nta.jeemain.paper1', curriculumVersion: '2026', objectiveCode: 'Physics Unit 2', level: 'JEE Main Paper 1' },
  ] },
  'physics.kinematics.projectile-motion': { subject: 'physics', refs: [
    { curriculumKey: 'in.nta.jeemain.paper1', curriculumVersion: '2026', objectiveCode: 'Physics Unit 2', level: 'JEE Main Paper 1' },
  ] },
};

function corpusMetadata(input: {
  key: string;
  version: string;
  conceptKey: string;
  evidencePurpose: StudyAssessmentEvidencePurpose;
  representation: StudyAssessmentRepresentation;
  prerequisiteConceptKeys?: string[];
}): StudyAssessmentCorpusMetadata {
  const mapping = CURRICULUM_BY_CONCEPT[input.conceptKey];
  if (!mapping) throw new Error(`Missing assessment corpus mapping for ${input.conceptKey}`);
  return {
    schemaVersion: STUDY_ASSESSMENT_CORPUS_SCHEMA_VERSION,
    subject: mapping.subject,
    curriculumRefs: mapping.refs.map((ref) => ({ ...ref })),
    evidencePurpose: input.evidencePurpose,
    representation: input.representation,
    prerequisiteConceptKeys: [...(input.prerequisiteConceptKeys || [])],
    provenance: {
      kind: 'quantora_authored',
      sourceRef: 'quantora:study-assessment-bank',
    },
    lifecycle: {
      state: 'released',
      previousState: 'approved',
      reviewRef: `quantora:study-assessment-bank:${input.key}@${input.version}`,
    },
  };
}

const ITEMS: StudyAssessmentItem[] = [
  {
    key: "trig-functions-quadrant-sign",
    version: "1",
    conceptKey: "math.trigonometry.functions",
    prompt: "An angle lies in quadrant II. Which statement must be true?",
    options: [
      { id: "a", text: "Its sine is positive and its cosine is negative." },
      { id: "b", text: "Its sine and cosine are both positive." },
      { id: "c", text: "Its sine is negative and its cosine is positive." },
      { id: "d", text: "Its sine and cosine are both negative." },
    ],
    correctOptionId: "a",
    explanation: "In quadrant II, the vertical coordinate is positive and the horizontal coordinate is negative, so sine is positive and cosine is negative.",
    difficulty: 0.35,
    objectiveCode: "trig-signs-q2",
    cognitiveOperation: "representation",
    misconceptionOptionIds: ["b", "c", "d"],
    misconceptionByOptionId: { b: "sign_error", c: "sign_error", d: "sign_error" },
    reviewStatus: "approved",
    releaseMode: "reviewed_static",
    corpus: corpusMetadata({ key: 'trig-functions-quadrant-sign', version: '1', conceptKey: 'math.trigonometry.functions', evidencePurpose: 'diagnostic', representation: 'spatial' }),
  },
  {
    key: "trig-identities-unit-circle",
    version: "1",
    conceptKey: "math.trigonometry.identities",
    prompt: "Which expression is equal to 1 for every angle x where the functions are defined?",
    options: [
      { id: "a", text: "sin(x) + cos(x)" },
      { id: "b", text: "sin²(x) + cos²(x)" },
      { id: "c", text: "tan(x) + cot(x)" },
      { id: "d", text: "sin(x)cos(x)" },
    ],
    correctOptionId: "b",
    explanation: "The Pythagorean identity sin²(x) + cos²(x) = 1 follows from the unit circle.",
    difficulty: 0.3,
    objectiveCode: "trig-pythagorean-identity",
    cognitiveOperation: "recall",
    misconceptionOptionIds: ["a", "c", "d"],
    misconceptionByOptionId: { a: "formula_selection", c: "formula_selection", d: "formula_selection" },
    reviewStatus: "approved",
    releaseMode: "reviewed_static",
    corpus: corpusMetadata({ key: 'trig-identities-unit-circle', version: '1', conceptKey: 'math.trigonometry.identities', evidencePurpose: 'retrieval', representation: 'symbolic', prerequisiteConceptKeys: ['math.trigonometry.functions'] }),
  },
  {
    key: "scalar-vector-classification",
    version: "1",
    conceptKey: "math.vector.scalar-vector",
    prompt: "Which quantity requires both a magnitude and a direction to be fully specified?",
    options: [
      { id: "a", text: "Temperature" },
      { id: "b", text: "Mass" },
      { id: "c", text: "Velocity" },
      { id: "d", text: "Time" },
    ],
    correctOptionId: "c",
    explanation: "Velocity is a vector: its magnitude alone does not specify the direction of motion.",
    difficulty: 0.25,
    objectiveCode: "vector-scalar-classification",
    cognitiveOperation: "recall",
    misconceptionOptionIds: ["a", "b", "d"],
    misconceptionByOptionId: { a: "conceptual_inversion", b: "conceptual_inversion", d: "conceptual_inversion" },
    reviewStatus: "approved",
    releaseMode: "reviewed_static",
    corpus: corpusMetadata({ key: 'scalar-vector-classification', version: '1', conceptKey: 'math.vector.scalar-vector', evidencePurpose: 'retrieval', representation: 'text' }),
  },
  {
    key: "vector-resultant-perpendicular",
    version: "1",
    conceptKey: "math.vector.resultant",
    prompt: "A 3 N eastward force and a 4 N northward force act together. What is the magnitude of their resultant?",
    options: [
      { id: "a", text: "1 N" },
      { id: "b", text: "5 N" },
      { id: "c", text: "7 N" },
      { id: "d", text: "12 N" },
    ],
    correctOptionId: "b",
    explanation: "The forces are perpendicular, so the resultant magnitude is √(3² + 4²) = 5 N.",
    difficulty: 0.45,
    objectiveCode: "vector-resultant-perpendicular",
    cognitiveOperation: "application",
    misconceptionOptionIds: ["c"],
    misconceptionByOptionId: { c: "rule_outside_domain" },
    reviewStatus: "approved",
    releaseMode: "reviewed_static",
    corpus: corpusMetadata({ key: 'vector-resultant-perpendicular', version: '1', conceptKey: 'math.vector.resultant', evidencePurpose: 'application', representation: 'quantitative', prerequisiteConceptKeys: ['math.vector.scalar-vector'] }),
  },
  {
    key: "vector-components-angle",
    version: "1",
    conceptKey: "math.vector.components",
    prompt: "A vector of magnitude V makes an angle θ above the positive x-axis. What is its x-component?",
    options: [
      { id: "a", text: "V sin(θ)" },
      { id: "b", text: "V cos(θ)" },
      { id: "c", text: "V tan(θ)" },
      { id: "d", text: "V / cos(θ)" },
    ],
    correctOptionId: "b",
    explanation: "The x-component is adjacent to θ in the component triangle, so it is V cos(θ).",
    difficulty: 0.4,
    objectiveCode: "vector-resolve-x-component",
    cognitiveOperation: "representation",
    misconceptionOptionIds: ["a"],
    misconceptionByOptionId: { a: "representation_misread" },
    reviewStatus: "approved",
    releaseMode: "reviewed_static",
    corpus: corpusMetadata({ key: 'vector-components-angle', version: '1', conceptKey: 'math.vector.components', evidencePurpose: 'diagnostic', representation: 'symbolic', prerequisiteConceptKeys: ['math.trigonometry.functions', 'math.vector.scalar-vector'] }),
  },
  {
    key: "kinematics-acceleration-change",
    version: "1",
    conceptKey: "physics.kinematics.speed-velocity-acceleration",
    prompt: "A car's velocity changes from 6 m/s east to 14 m/s east in 4 s. What is its average acceleration?",
    options: [
      { id: "a", text: "2 m/s² east" },
      { id: "b", text: "5 m/s² east" },
      { id: "c", text: "8 m/s² east" },
      { id: "d", text: "20 m/s² east" },
    ],
    correctOptionId: "a",
    explanation: "Average acceleration is the velocity change divided by time: (14 - 6) / 4 = 2 m/s² east.",
    difficulty: 0.4,
    objectiveCode: "kinematics-average-acceleration",
    cognitiveOperation: "application",
    misconceptionOptionIds: ["b", "c"],
    misconceptionByOptionId: { b: "formula_selection", c: "rule_outside_domain" },
    reviewStatus: "approved",
    releaseMode: "reviewed_static",
    corpus: corpusMetadata({ key: 'kinematics-acceleration-change', version: '1', conceptKey: 'physics.kinematics.speed-velocity-acceleration', evidencePurpose: 'application', representation: 'quantitative' }),
  },
  {
    key: "motion-graphs-velocity-slope",
    version: "1",
    conceptKey: "physics.kinematics.motion-graphs",
    prompt: "On a displacement-time graph, what does the slope at a point represent?",
    options: [
      { id: "a", text: "Acceleration" },
      { id: "b", text: "Displacement" },
      { id: "c", text: "Velocity" },
      { id: "d", text: "Distance travelled" },
    ],
    correctOptionId: "c",
    explanation: "The slope is change in displacement divided by change in time, which is velocity.",
    difficulty: 0.35,
    objectiveCode: "motion-graph-displacement-slope",
    cognitiveOperation: "representation",
    misconceptionOptionIds: ["a"],
    misconceptionByOptionId: { a: "representation_misread" },
    reviewStatus: "approved",
    releaseMode: "reviewed_static",
    corpus: corpusMetadata({ key: 'motion-graphs-velocity-slope', version: '1', conceptKey: 'physics.kinematics.motion-graphs', evidencePurpose: 'diagnostic', representation: 'graph_interpretation', prerequisiteConceptKeys: ['physics.kinematics.speed-velocity-acceleration'] }),
  },
  {
    key: "motion-graphs-acceleration-slope",
    version: "1",
    conceptKey: "physics.kinematics.motion-graphs",
    prompt: "On a velocity-time graph, what does the slope at a point represent?",
    options: [
      { id: "a", text: "Acceleration" },
      { id: "b", text: "Velocity" },
      { id: "c", text: "Displacement" },
      { id: "d", text: "Distance travelled" },
    ],
    correctOptionId: "a",
    explanation: "The slope is change in velocity divided by change in time, which is acceleration.",
    difficulty: 0.4,
    objectiveCode: "motion-graph-velocity-slope",
    cognitiveOperation: "representation",
    misconceptionOptionIds: ["b", "c", "d"],
    misconceptionByOptionId: { b: "representation_misread", c: "representation_misread", d: "representation_misread" },
    reviewStatus: "approved",
    releaseMode: "reviewed_static",
    corpus: corpusMetadata({ key: 'motion-graphs-acceleration-slope', version: '1', conceptKey: 'physics.kinematics.motion-graphs', evidencePurpose: 'misconception_probe', representation: 'graph_interpretation', prerequisiteConceptKeys: ['physics.kinematics.speed-velocity-acceleration'] }),
  },
  {
    key: "motion-plane-independent-components",
    version: "1",
    conceptKey: "physics.kinematics.motion-in-plane",
    prompt: "For ideal two-dimensional motion with constant downward gravity, which statement is correct?",
    options: [
      { id: "a", text: "Horizontal acceleration equals vertical acceleration." },
      { id: "b", text: "Horizontal and vertical components can be analysed independently using the same time." },
      { id: "c", text: "Vertical velocity remains constant." },
      { id: "d", text: "Horizontal motion determines the downward acceleration." },
    ],
    correctOptionId: "b",
    explanation: "The two components share time but obey separate component equations; gravity acts vertically in the ideal model.",
    difficulty: 0.55,
    objectiveCode: "motion-plane-component-independence",
    cognitiveOperation: "representation",
    misconceptionOptionIds: ["a", "c", "d"],
    misconceptionByOptionId: { a: "component_confusion", c: "component_confusion", d: "component_confusion" },
    reviewStatus: "approved",
    releaseMode: "reviewed_static",
    corpus: corpusMetadata({ key: 'motion-plane-independent-components', version: '1', conceptKey: 'physics.kinematics.motion-in-plane', evidencePurpose: 'diagnostic', representation: 'text', prerequisiteConceptKeys: ['math.vector.components', 'physics.kinematics.speed-velocity-acceleration'] }),
  },
  {
    key: "projectile-horizontal-velocity",
    version: "1",
    conceptKey: "physics.kinematics.projectile-motion",
    prompt: "Ignoring air resistance, what happens to a projectile's horizontal velocity while it is in flight?",
    options: [
      { id: "a", text: "It increases because gravity acts forward." },
      { id: "b", text: "It decreases at 9.8 m/s each second." },
      { id: "c", text: "It remains constant." },
      { id: "d", text: "It becomes zero at the highest point." },
    ],
    correctOptionId: "c",
    explanation: "With no air resistance there is no horizontal force, so horizontal acceleration is zero and horizontal velocity stays constant.",
    difficulty: 0.4,
    objectiveCode: "projectile-horizontal-component",
    cognitiveOperation: "error_detection",
    misconceptionOptionIds: ["b", "d"],
    misconceptionByOptionId: { b: "component_confusion", d: "component_confusion" },
    reviewStatus: "approved",
    releaseMode: "reviewed_static",
    corpus: corpusMetadata({ key: 'projectile-horizontal-velocity', version: '1', conceptKey: 'physics.kinematics.projectile-motion', evidencePurpose: 'diagnostic', representation: 'text', prerequisiteConceptKeys: ['physics.kinematics.motion-in-plane'] }),
  },
];

function cloneItem(item: StudyAssessmentItem): StudyAssessmentItem {
  return {
    ...item,
    options: item.options.map((option) => ({ ...option })),
    misconceptionOptionIds: [...item.misconceptionOptionIds],
    misconceptionByOptionId: { ...item.misconceptionByOptionId },
    corpus: {
      ...item.corpus,
      curriculumRefs: item.corpus.curriculumRefs.map((ref) => ({ ...ref })),
      prerequisiteConceptKeys: [...item.corpus.prerequisiteConceptKeys],
      provenance: { ...item.corpus.provenance },
      lifecycle: { ...item.corpus.lifecycle },
    },
  };
}

export function allStudyAssessmentItems(): StudyAssessmentItem[] {
  return ITEMS.map(cloneItem);
}

export function studyAssessmentItemsForConcept(conceptKey: string): StudyAssessmentItem[] {
  return ITEMS.filter((item) => item.conceptKey === conceptKey).map(cloneItem);
}

export function findStudyAssessmentItem(itemKey: string, version: string): StudyAssessmentItem | null {
  const item = ITEMS.find((candidate) => candidate.key === itemKey && candidate.version === version);
  return item ? cloneItem(item) : null;
}

export function publicStudyAssessmentItem(item: StudyAssessmentItem) {
  return {
    itemKey: item.key,
    itemVersion: item.version,
    conceptKey: item.conceptKey,
    prompt: item.prompt,
    options: item.options.map((option) => ({ ...option })),
    responseFormat: "single_correct" as const,
  };
}