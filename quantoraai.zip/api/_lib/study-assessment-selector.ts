import { verifyStudyAssessmentRelease } from './study-assessment-governance.js';
import { admittedStudyMasteryEvidence } from './study-evidence-admission.js';
import type { StudyAssessmentItem } from './study-assessment-items.js';
import { emitStudyLearningFlowMetric } from './study-learning-flow-telemetry.js';
import type { StudyLearnerModel } from './study-learner-model.js';
import type { StudyMisconceptionCode } from './study-misconception-taxonomy.js';
import type { StudyEvidenceKind, StudyMasteryEvidenceEvent } from './study-truth-layer.js';

export const STUDY_ASSESSMENT_SELECTOR_VERSION = 'study-assessment-selector-2026-09-09.3';

function discriminatesMisconception(item: StudyAssessmentItem, code: StudyMisconceptionCode): boolean {
  const mapped = Object.values(item.misconceptionByOptionId).filter(Boolean);
  return mapped.length > 0 && mapped.includes(code) && mapped.every((mappedCode) => mappedCode === code);
}

function isReleased(item: StudyAssessmentItem): boolean {
  return verifyStudyAssessmentRelease(item).canIssueVerifiedAttempt;
}

/**
 * Translate already-reviewed cognitive-operation metadata into an evidence
 * purpose. This never upgrades an unreviewed item: release governance is still
 * checked separately, and retention/transfer are never inferred here.
 */
export function studyEvidenceKindForAssessmentItem(item: StudyAssessmentItem): Extract<StudyEvidenceKind,
  'assessment_item' | 'retrieval' | 'application'> {
  if (item.cognitiveOperation === 'recall') return 'retrieval';
  if (item.cognitiveOperation === 'application') return 'application';
  return 'assessment_item';
}

/**
 * Pick the next server-owned governed item without allowing the browser to
 * choose an answer key, evidence purpose or diagnosis.
 *
 * - Unreleased candidates are never eligible.
 * - Freshness follows the grading RPC's learner-global item/version boundary,
 *   with concept-local admitted evidence retained as a second defensive source.
 * - An active misconception candidate may receive only a fresh reviewed item
 *   whose distractor mapping discriminates that same code. A mixed-code item
 *   cannot promote the candidate merely because it mentions the code.
 * - During evidence variation, prefer a fresh reviewed item whose reviewed
 *   cognitive operation contributes a genuinely new evidence kind.
 * - Exhaustion returns null rather than issuing non-independent evidence as if
 *   it could advance verified learning.
 */
export function selectStudyAssessmentItem(input: {
  items: StudyAssessmentItem[];
  evidence?: StudyMasteryEvidenceEvent[] | null;
  learnerModel?: StudyLearnerModel | null;
  usedItemRefs?: ReadonlySet<string> | null;
}): StudyAssessmentItem | null {
  const releasedItems = (Array.isArray(input.items) ? input.items : []).filter(isReleased);
  if (!releasedItems.length) {
    emitStudyLearningFlowMetric({ metric: 'assessment_availability', outcome: 'assessment_unavailable' });
    return null;
  }

  const admitted = admittedStudyMasteryEvidence(input.evidence || []);
  const usedItemRefs = new Set<string>(input.usedItemRefs || []);
  for (const event of admitted) {
    if (typeof event.itemRef === 'string' && event.itemRef.length > 0) usedItemRefs.add(event.itemRef);
  }
  const isFresh = (item: StudyAssessmentItem) => !usedItemRefs.has(`${item.key}@${item.version}`);
  const activeCode = input.learnerModel?.misconception.code || null;

  if (activeCode) {
    const confirmation = releasedItems.find((item) => isFresh(item) && discriminatesMisconception(item, activeCode)) || null;
    if (!confirmation) {
      emitStudyLearningFlowMetric({
        metric: 'assessment_availability',
        outcome: 'misconception_confirmation_unavailable',
      });
    }
    return confirmation;
  }

  const fresh = releasedItems.filter(isFresh);
  if (!fresh.length) {
    emitStudyLearningFlowMetric({ metric: 'assessment_availability', outcome: 'assessment_bank_exhausted' });
    return null;
  }

  if (input.learnerModel?.nextLearningMove.type === 'vary_evidence') {
    const existingKinds = new Set(input.learnerModel.understanding.evidenceKinds);
    const novel = fresh.find((item) => !existingKinds.has(studyEvidenceKindForAssessmentItem(item)));
    if (novel) return novel;
  }

  return fresh[0] || null;
}
